Gyetvai, Attila and Maria Zhu (2025). “Coworker Networks and the Role of Occupations in Job Finding.” Labour Economics

OVERVIEW
The code in this replication package constructs the analysis sample and runs the empirical analysis using Stata. 

DATA STATEMENT
This paper uses data provided by the Databank of the HUN-REN Center for Economic and Regional Studies (CERS). The data are under the ownership of the Hungarian State Treasury, the National Health Insurance Fund, the Educational Authority, the National Tax and Customs Administration, and the Ministry of Economic Development. The data were processed by the CERS Databank. Access to the data are limited to researchers upon request. Consult the CERS Databank website for details: https://adatbank.krtk.mta.hu/en/ (accessed on March 2, 2025)

DATASET LIST
The raw data are the base ADMIN2 data set (AdminII_alap.dta) and its additional data files on occupations (feor.dta) and firms (nav_eredeti.dta and vall_pan_szerver_17.dta). The paper also uses measures of monthly core inflation from the Hungarian Central Statistical Office (available as part of this replication package, and available at https://www.ksh.hu/stadat_files/ara/en/ara0045.html, accessed on March 2, 2025).

COMPUTATIONAL REQUIREMENTS
The analysis sample is to be constructed on the CERS Databank servers. The replicator should expect to run the files within 7-12 days (runtime depends on server congestion; consult the server administrators for running large jobs). Once the analysis sample is assembled, the empirical analysis can be run in approx. 5 minutes.

DESCRIPTION OF PROGRAMS
- setup.do: creates folder structure and installs third-party Stata packages
- build/shell.do: assembles and saves sample on the CERS Databank server
-- build/flag_displaced.do: flags displaced workers
--- build/aux/switchit.do: switches 1st and 2nd work arrangements by months to create continuous employment histories
--- build/aux/patchit.do: fills monthly and yearly gaps in employment histories
-- build/calc_network_measures.do: creates coworker networks and calculates their characteristics
-- build/assemble_sample.do: assembles sample to use on a local computer
-- build/calc_network_fe.do: calculates average fixed effects within networks
-- build/clean_sample.do: cleans and saves the final analysis sample
- calcs/create_sumstats.do: creates summary statistics
- calcs/estimate_models.do: estimates regression models and saves tables in the main text and appendices
- calcs/estimate_models_aux.do: creates additional results not reported in the paper

LIST OF TABLES AND GRAPHS
Table 3.1: Summary Statistics
- calcs/create_sumstats.do:35-48 > results/tables/sumstats.tex, results/tables/sumstats_educ.tex (manual formatting)
Figure 3.1: Network Employment Rate and Unemployment Duration
- calcs/create_sumstats.do:51-56 > results/graphs/durU_ersame.pdf, results/graphs/durU_erdiff.pdf
Table 4.1: Same- vs. Different-Occupation Network Employment Rates on Unemployment Duration
- calcs/estimate_models.do:51-73 > results/tables/tab_1.tex
Table 4.2: Network Employment Rate on Unemployment Duration: Detailed Occupational Similarity Breakdown
- calcs/estimate_models.do:76-101 > results/tables/tab_2.tex
Figure 4.1: Time-Varying Impact of Network Employment Rate on Job Finding Probability
- calcs/estimate_models.do:135-149 > results/tables/pr_e_months.xlsx (graph formatted manually)
Table 4.3: Network Employment Rate on Unemployment Duration by Occupation Education Requirements
- calcs/estimate_models.do:104-133 > results/tables/tab_3.tex (table structure only, results from regression inputted manually)
Appendix Figure A.1: Occupation Classification Example: Blacksmith
- created manually
Appendix Table A.1: Occupational Distribution of Displaced Workers
- calcs/create_sumstats.do:75-76 > table formatted manually
Appendix Table A.2: Most Prevalent Occupations
- calcs/create_sumstats.do:79-80 > table formatted manually
Appendix Table A.3: Coworkers-by-Occupation Counts Across Education Levels
- calcs/create_sumstats.do:83-100 > table formatted manually
Appendix Table A.4: Post-Displacement Outcomes across Occupational Education Levels
- calcs/create_sumstats.do:103-105 > table formatted manually
Appendix Figure A.2: Network Employment Rate and Job Finding Probability
- calcs/create_sumstats.do:59-72 > results/graphs/jobXm_ersame.pdf, results/graphs/jobXm_erdiff.pdf (X=1,3,6)
Appendix Table A.5: Effect of Network Employment Rate on Finding a Job within One Month of Displacement
- calcs/estimate_models.do:155-176 > results/tables/tab_a5.tex
Appendix Table B.1: Same- vs. Different-Occupation Network Employment Rates on Unemployment Duration—Excluding Large Networks
- calcs/estimate_models.do:182-206 > results/tables/tab_b1.tex
Appendix Table B.2: Network Employment Rate on Unemployment Duration: Detailed Occupational Similarity Breakdown—Excluding Large Networks
- calcs/estimate_models.do:209-235 > results/tables/tab_b2.tex
Appendix Table B.3: Network Employment Rate on Unemployment Duration by Occupation Education Requirements—Excluding Large Networks
- calcs/estimate_models.do:238-268 > results/tables/tab_b3.tex (table structure only, results from regression inputted manually)
